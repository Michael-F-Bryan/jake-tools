**Review of SYN-705 plan — (inspected revision `a1b2c3d`, synthetic)**

**Judgement: Blocked on a decision.** The plan bundles a small, well-evidenced fix for the reported over-alerting with a large, unrequested expansion of the responder's ownership (a new persistent state schema, a migration with rollback, a crash-safe outbox, and a new CI job). The planning comment asserts "No decision is needed from Michael" for that bundle — that's the wrong call. The actual over-reporting bug has a minimal fix that doesn't need any of this machinery, and should be scoped and reviewed separately from it.

---

**1. The reported bug has a much smaller fix than the plan adopts.**

Discovery is clear: 7 of 9 false alerts were non-consecutive failures with successes in between; both genuine outages were consecutive runs. The defect is entirely in `signal.py`:

```python
failed = Counter(r.target for r in recent if not r.ok)
return [Alert(t, "repeated_failure", n) for t, n in sorted(failed.items())
        if n >= THRESHOLD]
```

This counts failures in a 15-minute window regardless of adjacency. The fix that matches the evidence is to require **3 consecutive failing probes** for a target, not 3-in-a-window. Probes run every minute (`probe.py`), so 3 consecutive failures surface within ~3 minutes — comfortably inside the "within ~10 minutes" requirement — and isolated, recovered-in-between failures no longer qualify. This is a small, local, testable change to one 31-line file and needs no new module, no responder changes, and no new state.

The plan instead introduces a whole `classify.py` module with three categories (`isolated`, `probe_side`, `sustained`) before getting to the actual rule. Recommend starting from the consecutive-failure rule directly in `signal.py` (or a tiny helper), and only split into a separate module if a real second consumer of the classification shows up. This is a routine implementation choice, not a blocker — flagging it so the slice isn't over-built by default.

**2. The `probe_side` category is speculative and has no consumer.**

Nothing in the 30-day evidence shows an all-12-targets-failing event (0 of 9 alerts). The plan adds a label and "own counters for later tuning" for a scenario that hasn't been observed and that nothing reads. This is exactly the kind of hypothetical-consumer framework the ticket doesn't ask for. Recommend dropping `probe_side` from this change; it can be added later with its own evidence and consumer. This can be decided by the implementer — it doesn't need to block the rest.

**3. The board-silence bug is real but doesn't require versioned state, an incident model, or a migration.**

Discovery's trace is solid: during an ongoing outage, `render()` output is unchanged, so `run_once` returns `UNCHANGED` *before* writing state, so `last_seen` goes stale, so `board.py` reports "responder silent" on a healthy responder. That's a genuine bug worth fixing under "change responder behaviour where necessary."

But the necessary fix is to stop conflating "did we post" with "are we alive": write a heartbeat (`last_seen`) on every `run_once` call, independent of whether the digest changed and a post was made. That's a few lines in the existing function and schema — no `incident_id`, no `status`, no `publish_attempts`, no `state/outbox.jsonl`, no v1→v2 migration with `.bak` rollback. The plan's `assess()`/`publish()` split and durable outbox solve a crash-recovery scenario ("a crash between assessment and delivery") that is not evidenced anywhere in the issue or discovery — no report has been shown to have been lost. Recommend implementing the heartbeat decoupling only, in the existing single-file state shape; drop the versioned schema, migration, and outbox from this change unless Michael wants to scope that as a separate, evidence-backed piece of work.

**4. The new `responder-migration` CI job and state migration are the clearest case of unrequested ownership expansion.**

A migration script with fixtures for "6 historical v1 shapes," a `.bak`-based rollback, and a CI job that runs on every PR touching `state/` is substantial new operated infrastructure. The rubric point this trips is explicit: a migration and an operated CI job are the kind of commitment that needs Michael's decision, not quiet inclusion via "as agreed in discovery." Nothing in discovery agreed to this — discovery only raised "state may need versioning… whether this is one is open" and left it undecided. The plan treats an open question as settled. This needs to go back to Michael as an explicit proposal, separate from the fix being requested, with its own justification (what future responder change actually needs incident IDs, and why can't that be added when it's actually needed).

**5. Test/CI burden is disproportionate once the above is right-sized.**

38 new tests and a new CI job against a current base of 14 tests and 3 jobs is a large, ongoing maintenance commitment for what is, after removing the unnecessary pieces, a consecutive-failure rule and a one-line heartbeat fix. Right-sizing the design (points 1–4) will right-size verification to roughly: a handful of classifier/timing tests for the consecutive rule, a test that the board no longer reports false silence during an ongoing-but-unchanged outage, and a test that recovery still posts. No new CI job is needed for that.

---

**Summary for Michael:** The signal fix (consecutive failures, not windowed count) and the responder heartbeat decoupling are implementable now, as scoped-down corrections within this ticket's "where necessary" allowance. The versioned state/incident model, migration-with-rollback, crash-safe outbox, and new CI job are a material expansion of what's being asked and owned going forward; that part is blocked pending your decision on whether it's wanted at all, and if so, on what evidence of need (not "later tuning" or an unobserved crash scenario).