# Review: syn-705 — Isolated failed probes raise misleading repeated-failure warnings

**Blocked on a decision.** The plan treats a discovery question that was explicitly left open ("whether this is necessary... is open") as already decided, and uses that self-granted authorization to justify a four-slice rearchitecture (incident-keyed state v2, migration, durable outbox, new CI job) that is far larger than the "smallest supported correction" the ticket asks for. The signal-side fix is sound in direction and implementable; the responder-side scope needs Michael's sign-off before slices 2-4 start, because a much smaller fix appears to satisfy the actual discovered defect.

## 1. The responder rearchitecture is based on an authorization the plan grants itself, not one it was given

**What the plan does:** Discovery found the board's "responder silent" message is a real bug (`run_once` returns `UNCHANGED` without calling `save_state`, so `last_seen` goes stale even though the responder is healthy), but explicitly flagged *"whether this is [in scope] is open."* The plan's Decisions section closes that question unilaterally: *"the ticket's 'where necessary' authorises the responder work. No decision is needed from Michael,"* and proceeds to design incident-keyed state v2, `migrate_v1_to_v2()` with invented incident IDs, a durable outbox for crash-safe exactly-once publish, and a new CI job gating every PR that touches `state/`.

**Why this matters:** Nothing in the "must keep working" list (sustained outage reported once within 10 minutes; recovery announced) requires any of this. Both guarantees are already provided by the existing digest-comparison in `responder.py` and are orthogonal to how `signal.py` computes alerts. The actual discovered defect — stale `last_seen` on the `UNCHANGED` path — has a direct cause and a direct fix:

```python
def run_once(now: datetime) -> Outcome:
    report = render(signal.repeated_failures(load_rows(), now))
    digest = sha256(report.encode()).hexdigest()
    state = load_state()
    if digest == state.get("last_digest"):
        save_state({**state, "last_seen": now.isoformat()})   # heartbeat even when unchanged
        return Outcome.UNCHANGED
    post_to_channel("#ops-alerts", report)
    save_state({"last_digest": digest, "last_seen": now.isoformat(), "acknowledged": True})
    return Outcome.DELIVERED
```

This keeps the existing `{last_digest, last_seen, acknowledged}` shape, requires no new file, no migration, no outbox, and directly resolves the symptom discovery actually observed ("board showed silence for 30 minutes while the responder was healthy").

**Consequence for maintainers:** the proposed design adds a second state file, a backfill heuristic that "invents an `incident_id` for any open incident" with no stated correctness criterion, a crash-recovery guarantee (exactly-once delivery across assess/publish) nobody asked for or showed broken, and a permanent CI job scoped to `state/`. Anyone debugging "why didn't on-call get a repost" or "why does this incident ID not match the old digest-based report" six months from now inherits all of this, for a guarantee (crash-safe delivery) that isn't evidenced as a problem in the 30-day sample.

**Recommendation:** present the heartbeat fix above to Michael as the correction to the board-silence bug, in place of state v2/migration/outbox. If he wants versioned incident state for other reasons, that's a separate decision, not an implicit rider on this ticket.

**Status:** needs a decision from Michael before slices 2-4 are built — the discovery comment left this open, and the plan's claim that no decision is needed is itself the thing to challenge.

## 2. The `probe_side` classification category is unevidenced and silently changes alerting policy for a scenario nobody asked about

**What the plan does:** `classify.py` adds a third label, `probe_side`, for "all 12 targets failed in the same run," which is excluded from alerting, plus "counters for later tuning" on both `isolated` and `probe_side`.

**Why this matters:** Discovery's evidence table covers only two patterns — isolated single-target blips (7/9 alerts) and genuine single-target consecutive outages (2/9 alerts). None of the 30 days of alerts involved all 12 targets failing simultaneously. If that scenario ever occurs (e.g., the probe host loses network), it's plausibly the *most* urgent case, not one to suppress — and the plan bakes in suppression as a design default with no evidence it's correct and no flag to Michael that this is a policy call.

**Consequence:** a maintainer investigating "why didn't we get paged when every target failed at once" would have to discover this suppression buried in `classify.py`'s branch logic, with no decision record explaining it.

**Recommendation:** drop the `probe_side` branch and the tuning counters from this change. The ticket and the evidence only support a two-way distinction (sustained vs. not). If probe-side failures are later observed misfiring as 12 separate alerts, that's new evidence for a future, explicitly-scoped change.

**Status:** incorporable during implementation — this is a scope-narrowing correction, not a blocking unknown.

## 3. The core signal fix doesn't need a new module or persisted classifier state

**What the plan does:** adds `classify.py` as a separate component with its own counters, driven by the three-way label above.

**Why this matters:** `signal.repeated_failures(rows, now)` already receives ordered rows per target. Distinguishing "3 consecutive failures" from "3 failures within a 15-minute window" only requires checking that a target's most recent results contain no success between the last 3 failures — a small, stateless change inside `signal.py`, not a new abstraction:

```python
def repeated_failures(rows, now):
    by_target = group_sorted_by_ts(rows)
    alerts = []
    for target, target_rows in by_target.items():
        tail = target_rows[-THRESHOLD:]
        if len(tail) == THRESHOLD and all(not r.ok for r in tail):
            alerts.append(Alert(target, "repeated_failure", THRESHOLD))
    return alerts
```

**Consequence:** once concern 2 removes the `probe_side`/tuning-counter rationale for a separate module, there's no remaining reason for `classify.py` to be a distinct component — it would just be internal structure inside `signal.py`'s existing, well-tested function.

**Recommendation:** implement the consecutive-failure check as a revision to `signal.repeated_failures`, not a new module. This is a routine implementation choice, not something requiring sign-off.

**Status:** incorporable during implementation.

## 4. Delivery slicing is a symptom of concern 1, not an independent issue

The plan's own note that "slices 2-4 are tightly coupled" is a direct consequence of the state v2/migration/outbox design. Once concern 1 is resolved (heartbeat fix instead of incident-state rearchitecture), the work reduces to two independent slices — the signal fix, and the one-line heartbeat fix — with no migration fixtures, no new CI job, and no coupling to resolve.

---

**Summary for Michael:** the signal-side diagnosis (window-counting instead of consecutiveness) and its fix are well supported by the 30-day evidence and implementable now. The responder-side work is where the plan oversteps: it answers its own open question from discovery and builds a disproportionately large mechanism (versioned incident state, migration, outbox, dedicated CI job, 38 tests) to fix what the evidence shows is a one-line heartbeat bug. Recommend confirming the minimal heartbeat fix for the board-silence bug and dropping `probe_side`/tuning counters before implementation starts.