**Judgement: Blocked on a decision.** The signal fix (require *consecutive* failures rather than a windowed count) is sound, evidence-backed, and ready to implement on its own. But three of the plan's four delivery slices — versioned responder state, a migration layer, and a crash-recovery outbox — rest on a decision the plan claims was already made when it wasn't, and the resulting architecture is disproportionate to what the ticket actually needs fixed. That needs Michael's sign-off before slices 2–4 proceed, not silent authorization inside the plan.

---

### 1. The plan treats an explicitly open question as settled, and uses that to license most of its scope

The discovery comment says, under "Possible follow-up (**not decided**)":

> State may need versioning if more responder changes follow. The ticket allows responder changes "where necessary"; whether this is one is open.

The planning comment then states:

> As agreed in discovery, versioned state is part of this change, and the ticket's "where necessary" authorises the responder work. **No decision is needed from Michael.**

That's not what discovery said — it flagged versioning as a maybe, not an agreement. The plan has converted an open question into a requirement and used it to justify incident-record state (`incident_id`, `status`, `publish_attempts`), a migration tool with `.bak` rollback, a durable outbox, and a dedicated CI job. That's the bulk of the proposed work, built on a decision that was never actually taken.

**Consequence:** if this ships as planned, Michael inherits a four-times-larger surface (new schema, migration code, outbox, CI job) than the ticket asked for, without having chosen to take on that ongoing maintenance cost.

**Recommendation:** present the responder/board fix as a separate decision point for Michael — "do you want the board-silence bug fixed, and if so, how much apparatus is justified?" — rather than folding it into the plan as already authorized. This needs a decision, not an implementation correction.

---

### 2. Even if the board-silence bug is in scope, the proposed fix is far heavier than the bug requires

The actual bug (from discovery): `run_once` returns `UNCHANGED` without writing state when the report digest hasn't changed, so `last_seen` goes stale and `board.py`'s 30-minute silence check fires even though the responder is healthy and the outage is unchanged, not unmonitored.

```python
if digest == state.get("last_digest"):
    return Outcome.UNCHANGED                 # nothing written
```

This is fixable by separating "last time we checked" from "last time the posted content changed" — a single additional field, written unconditionally, in the *existing* file:

```python
def run_once(now: datetime) -> Outcome:
    report = render(signal.repeated_failures(load_rows(), now))
    digest = sha256(report.encode()).hexdigest()
    state = load_state()
    changed = digest != state.get("last_digest")
    if changed:
        post_to_channel("#ops-alerts", report)
    save_state({"last_digest": digest if changed else state.get("last_digest"),
                "last_assessed": now.isoformat(),
                "last_seen": now.isoformat() if changed else state.get("last_seen"),
                "acknowledged": True})
    return Outcome.DELIVERED if changed else Outcome.UNCHANGED
```

`board.py` reads `last_assessed` for the silence check. No new file, no `incident_id`, no versioning, no migration: `responder.py` is the sole writer and `board.py` the sole reader of this state (confirmed in the code excerpts), so both sides can change together in one commit with no compatibility concern to manage.

**Consequence of the heavier version:** incident lifecycle fields (`status`, `publish_attempts`), a second file (`outbox.jsonl`), and migration fixtures are permanent things a future maintainer has to understand and keep correct, for a bug whose actual fix is a one-field addition to a 58-line module.

**Recommendation:** implement the minimal field-separation fix above instead of state v2. This can be incorporated directly during implementation — it doesn't need new design discussion.

---

### 3. The migration layer's premise isn't supported by evidence

The plan calls for "migration fixtures for 6 historical v1 shapes" and a `.bak`-based rollback. The code excerpts show exactly one v1 shape (`{last_digest, last_seen, acknowledged}`), and nothing in discovery or the issue indicates schema drift across deployments. There's no evidence of 6 historical shapes to migrate from.

**Consequence:** building migration tooling for variation that hasn't been shown to exist adds code and a new CI job (`responder-migration`, gating "every PR touching `state/`") to guard against a problem not in evidence, while adding ongoing friction for unrelated changes to that directory.

**Recommendation:** if state v2 is dropped per #2, this is moot. If Michael still wants versioned state for other reasons, treat migration as a separate, evidence-gated follow-up — don't build 6 fixtures for shapes nobody has observed.

---

### 4. `probe_side` classification has no supporting evidence and no defined consumer

The classifier splits failures into `isolated`, `probe_side` (all 12 targets failing in the same run), and `sustained`. The discovery evidence table shows two failure patterns: isolated-with-recovery (7/9 alerts) and genuine consecutive outages (2/9). Simultaneous all-target failure doesn't appear in the data at all. The plan also says `probe_side` and `isolated` each get "their own counters for later tuning" — with no reader specified for those counters.

**Consequence:** this adds a classification branch and two unread counters to maintain, justified by a scenario not seen in the 30-day alert history and a consumer ("later tuning") that doesn't exist yet. That's speculative scope riding along with the requested fix.

**Recommendation:** the minimal correction for the stated problem is: alert only when a target has failed on the last `THRESHOLD` *consecutive* probes, full stop. Drop the `probe_side` branch and counters unless Michael specifically wants probe-infrastructure failures distinguished — in which case that's a separate, explicit requirement, not an inferred one. This is a correction implementable now (removing scope), not a blocking question.

---

### 5. The outbox's crash-recovery guarantee addresses an unobserved failure mode

Slice 3 introduces `state/outbox.jsonl` specifically so that "a crash between assessment and delivery re-sends exactly one report." Nothing in the issue or discovery describes a missed or duplicated post, a delivery failure, or a crash during posting. This is new resilience machinery for a failure mode with zero evidence it has occurred.

**Consequence:** a durable outbox is a stateful component with its own failure modes (partial writes, duplicate delivery on replay, ordering during concurrent runs) that a future maintainer now has to reason about, for a guarantee nobody asked for.

**Recommendation:** defer. If a real crash-during-post incident occurs, that's the evidence needed to justify this mechanism. Needs a decision if pursued now — it isn't implied by the ticket's "where necessary."

---

### What's settled and ready

The core diagnosis and fix — switch `signal.repeated_failures` from "≥3 failed rows in a 15-minute window" to "≥3 *consecutive* failed probes" — is well-supported by the discovery data (7/9 historical alerts were non-consecutive flaps; both genuine outages were consecutive) and satisfies both "must keep working" clauses (3 consecutive 1-minute probes complete well inside the 10-minute bound; the existing digest-diff in `responder.py` already ensures a sustained outage is reported once and recovery is announced via the unchanged "All clear" path). This part doesn't need to be reopened or redesigned — implement it directly, without the `probe_side` branch (#4) and without making it depend on state v2 (#1–#2).