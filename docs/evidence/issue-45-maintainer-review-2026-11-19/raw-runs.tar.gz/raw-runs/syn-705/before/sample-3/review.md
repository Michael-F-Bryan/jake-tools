**Judgement: Blocked on a decision.**

The signal fix (slice 1) is close to ready, but the plan builds its entire responder redesign (slices 2–4: incident-keyed state, versioning, migration, a durable outbox, a new CI job) on a claim that this scope is already settled. It isn't, and the actual bug the discovery comment found doesn't require any of it. Michael should decide the scope before slices 2–4 are built.

## 1. The plan asserts a decision that discovery explicitly left open

Discovery's closing note says:

> Possible follow-up (not decided). State may need versioning if more responder changes follow. The ticket allows responder changes "where necessary"; whether this is one is open.

The plan then says:

> As agreed in discovery, versioned state is part of this change, and the ticket's "where necessary" authorises the responder work. No decision is needed from Michael.

That's not what discovery said — it flagged versioning as an open question, not an agreement. Treating "open" as "agreed" is how a ticket asking for "the smallest supported correction" turns into a new state schema, a migration tool, a crash-recovery outbox, and a new CI job. This should go back to Michael as a scope question, not be implemented on the premise that it's already decided.

## 2. The actual board bug has a much smaller fix than the one proposed

The real defect discovery found is narrow and well-evidenced:

```python
def run_once(now: datetime) -> Outcome:
    ...
    if digest == state.get("last_digest"):
        return Outcome.UNCHANGED                 # nothing written
    ...
    save_state({"last_digest": digest, "last_seen": now.isoformat(), ...})
```

`last_seen` only advances on `DELIVERED`. A healthy, unchanged incident report makes `board.py` think the responder died after 30 minutes. The fix is: record a "last checked" timestamp on every `run_once` call, delivered or not, and have `board.py`'s silence check read that timestamp instead of (or alongside) `last_seen`. That's a one-field addition to the existing state shape and a one-line change to `board.py`'s read — no incident IDs, no v2 schema, no outbox, no migration tool, no `.bak` rollback path, no new CI job.

The plan's `assess()`/`publish()` split and outbox exist to solve a different, unrequested problem — guaranteeing exactly-once delivery across a crash between posting and saving state — which nothing in the ticket or discovery asks for. Before that machinery is built, Michael should confirm it's in scope; as framed, it's the responder team inventing a requirement and then citing "where necessary" to self-authorize it.

## 3. If the v2/migration design proceeds anyway, its contract has a hole

`migrate_v1_to_v2()` is supposed to "invent an `incident_id` for any open incident" from the v1 file. But v1 state is:

```python
STATE = Path("state/responder_state.json")   # {"last_digest": str, "last_seen": iso, "acknowledged": bool}
```

This is a single digest of the *whole composed report* (potentially covering multiple targets), not a per-target or per-incident record. There is no way to recover "which target's incident was open" or "when did it start" from a hash of concatenated alert lines — the information needed to backfill `first_seen`/`last_assessed` per incident was never recorded. This isn't a complexity concern, it's a missing contract: the migration function has no well-defined input to work from. If slices 2–4 go forward, this needs to be resolved (e.g., by deciding migrated incidents start "unknown-since-now" rather than backfilled) before it can be implemented, not discovered during the fixture work.

## 4. `probe_side` classification has no evidence behind it

The discovery comment's 30-day sample covers 9 alerts: 7 isolated-failure false positives, 2 genuine consecutive-failure outages. Nothing in that data shows a case where all 12 targets failed in the same run. `classify.py`'s `probe_side` category, plus "its own counters for later tuning," is being added speculatively, with no consumer for the counters and no evidence it's a real failure mode here. Recommend dropping `probe_side` from this change and keeping the classifier to `isolated` vs `sustained`, which is what the ticket and evidence actually call for. If probe-wide failures turn out to matter later, add the category when there's a real instance to design against.

## 5. The outbox's "exactly one" claim is stronger than the mechanism delivers

Only relevant if slices 2–4 survive the scope decision above, but worth noting now: "a crash between assessment and delivery re-sends exactly one report" doesn't hold if the crash happens *after* `post_to_channel` succeeds but *before* the outbox entry is marked sent — replay will post the same report again. That's at-least-once, not exactly-once, unless there's an idempotency key on the channel side that isn't described anywhere here. The guarantee as stated should be corrected to match what the mechanism can actually promise.

---

**Summary of what's needed before implementation:**
- Michael decides whether the responder redesign (state v2, outbox, migration, new CI job) is in scope, given that discovery left it explicitly open and the only found bug has a much smaller fix (#2).
- Drop `probe_side` from the classifier unless there's a concrete case for it (#4).
- If the v2/migration path is approved, resolve the incident-identity gap in `migrate_v1_to_v2()` before building fixtures against it (#3).
- Correct the outbox's delivery guarantee wording if that mechanism is approved (#5).

The signal-counting fix itself (consecutive-failure detection instead of window-count) is sound and matches the evidence; it can proceed once the classifier is narrowed per #4.