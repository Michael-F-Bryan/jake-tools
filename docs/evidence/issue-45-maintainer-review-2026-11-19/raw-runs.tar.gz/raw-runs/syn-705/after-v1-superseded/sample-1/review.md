**Judgement: Blocked on a decision or missing evidence** — specifically, the responder redesign (versioned state, migration, outbox, new CI job) is a significant ownership expansion that the plan asserts is already authorized ("No decision is needed from Michael"), when it isn't. The signal fix itself (slice 1) is sound in direction and implementable with corrections.

## 1. The responder rewrite is scope the plan self-authorizes, not scope the ticket grants

The ticket's only responder-facing requirement is conditional: "change responder behaviour **where necessary**." Discovery found exactly one responder defect: `run_once` returns `UNCHANGED` without updating `last_seen`, so during a long unchanging outage the board shows "responder silent" even though the responder is healthy. Discovery itself flags this as open ("whether this is one is open").

The plan converts that single, local defect into: a new per-incident state schema (`incident_id`, `status`, `publish_attempts`, …), a `migrate_v1_to_v2()` with six historical fixture shapes, a durable `outbox.jsonl` for crash recovery, a split of `run_once` into `assess()`/`publish()`, and a new CI job (`responder-migration`) gating every PR that touches `state/`. Then it states: "No decision is needed from Michael." That contradicts the review guidance directly: a new persistent-state format, a migration path, and a new CI job are exactly the kind of changes that need Michael's decision, and discovery's own "not decided" framing doesn't become a decision just because the plan repeats it.

The defect itself has a two-line fix: update `last_seen` on every call to `run_once`, independent of whether the digest changed (i.e., separate "last ran/healthy" from "last posted a change"). No incident IDs, no outbox, no migration, no new file format are needed to make that true.

**Recommendation:** Implement the minimal `last_seen` fix now. Treat the state-v2/outbox/migration/CI-job proposal as a separate request for Michael's decision — it is not settled by this ticket.
**Status:** Blocked on Michael's decision before slices 2–4 proceed.

## 2. The outbox/crash-recovery mechanism answers a problem with no evidence

The plan justifies the outbox by needing to resolve "the 'unchanged recurrence cannot complete without another report' limitation" and guard against "a crash between assessment and delivery." Nothing in the issue or the 30-day `#ops-alerts` sample shows a missed or duplicated delivery due to a crash — the only observed symptom is the board's false "silent" status, which is a staleness/observability bug, not a lost-message bug.

Adding `outbox.jsonl`, publish-attempt counters, and crash-point tests introduces new persistent state and new failure modes (e.g., double-posting if replay logic is off by one) to defend against a scenario that hasn't been observed.

**Recommendation:** Drop the outbox/publish-attempt machinery from this change. If delivery loss on crash is later observed operationally, raise it as its own ticket with evidence.
**Status:** Part of the decision in concern 1; should not proceed without evidence.

## 3. The `probe_side` classification is speculative and unused

`classify.py` proposes three labels — `isolated`, `probe_side` (all 12 targets fail in the same run), `sustained` — with `isolated` and `probe_side` getting "their own counters for later tuning." But discovery's breakdown of the 9 sampled alerts shows only two patterns: scattered isolated failures (7/9) and genuinely consecutive outages (2/9). No whole-fleet simultaneous failure appears in the evidence, and nothing in the ticket asks for a probe-side distinction. "For later tuning" is a hypothetical future consumer, not a current one.

**Recommendation:** Build only the distinction the evidence and ticket require — consecutive vs. scattered failures per target. Drop `probe_side` and its counters; if simultaneous whole-fleet failures turn out to be a real recurring pattern, that's a separate, evidenced ticket.
**Status:** Trim during implementation; doesn't need a decision, it's simply out of scope.

## 4. A separate `classify.py` module is more machinery than the fix needs

Even restricted to isolated-vs-sustained, a new module is unnecessary. `signal.py` is 31 lines today and already has the rows it needs; `repeated_failures` can check directly whether a target's last 3 rows in the window are consecutive failures with no intervening success, replacing the current `Counter`-based count. That keeps the fix inside the one function that owns the alerting predicate, with no new interface for a classifier that currently has exactly one caller.

**Recommendation:** Fold the "3 consecutive failed probes, no success between them" check into `signal.repeated_failures` directly.
**Status:** Implementation detail; correct during implementation, no decision needed.

## 5. Verification scope should track the actual fix, not the proposed architecture

38 new tests plus a dedicated `responder-migration` CI job (running on every PR touching `state/`) is a standing maintenance cost disproportionate to a targeted alerting fix. The current suite is 14 tests across the whole module set. Once concerns 1–3 are resolved, the needed coverage is small: a handful of consecutive-vs-scattered signal cases, a test that `last_seen` advances on `UNCHANGED` outcomes, and the existing recovery-announcement test left intact.

**Recommendation:** Scope tests to the corrected behaviour; no new CI job.
**Status:** Resolves automatically once concern 1 is settled.

## What's sound and should proceed

The core diagnosis — alert on *consecutive* failures per target rather than raw count-in-window — correctly matches the evidence (7/9 false alerts had successes between failures; both genuine outages were consecutive runs) and preserves the "sustained outage reported once within ~10 minutes" requirement (3 consecutive 1-minute probes = 3 minutes). That part of the plan is implementable now, independent of the responder-redesign decision above.