## Review: SYN-705 (subtle variant)

**Judgement: Blocked on a decision for part of the plan.** The signal correction (alert on consecutive failures, not a windowed count) is the right fix and is close to implementable, but it has a concrete gap that must be resolved first (see #1). Separately, the responder rewrite — state v2, schema migration, `open_incidents`, and a new CI job — is scope expansion beyond what this ticket asks for, justified by an unrelated pre-existing bug rather than by the stated requirements. That expansion needs Michael's explicit sign-off, not an inferred license from "where necessary."

### 1. The new signal risks breaking "reported once" for every sustained outage — must fix before implementing

The plan says `repeated_failures` should alert "when a target's most recent 3 rows are all failures," replacing the windowed count, but doesn't say what `Alert.count` becomes. If it's the length of the current failure streak (the natural reading of "replacing the windowed count"), then for a genuine outage the count — and therefore `render()`'s output and its digest — changes every single minute the outage continues:

```
minute 3: "REPEATED FAILURE billing-api x3"
minute 4: "REPEATED FAILURE billing-api x4"
minute 5: "REPEATED FAILURE billing-api x5"
...
```

`run_once` posts whenever the digest differs from `last_digest`. A 41-minute outage would post ~39 times, not once — violating the ticket's explicit "reported, once" requirement.

Note this isn't hypothetical: under the *current* windowed count, the two real outages (41 min, 95 min) only looked like one post because they ran long enough to saturate the 15-minute window, after which the count stopped changing — which is exactly the mechanism the discovery comment found to cause the "responder silent" board bug. The new, uncapped consecutive-count removes that saturation, so the masking goes away and the repeated-post behavior would show up on *every* sustained outage, not just ones that happen to outlast the window.

**Recommendation:** decide what identifies an alert for dedup purposes — e.g. key the digest/report on `(target, kind)` presence rather than raw escalating count, or cap the displayed count once the alert is active, so the report (and its digest) is stable for the duration of one outage and only changes on start/recovery. This is a small, contained correction to `signal.py`/`render()`, not a reason by itself to introduce state versioning.

This can be corrected during implementation — it doesn't need a new component, just a clear definition of what "unchanged" means for an active alert.

### 2. The responder/state-v2/CI-schema work fixes a different, pre-existing bug and is not required by this ticket

The planning comment justifies `assess`/`publish` split, `responder_state_v2.json`, `open_incidents`, a v1→v2 migration path, and a new CI job validating `state/schema.json` on every PR touching `state/`, by appeal to the ticket's "change responder behaviour where necessary."

But look at what "necessary" is actually resolving: the board showing "responder silent" during a long *unchanged* report, because `run_once` only records `last_seen` when it posts. That's a real bug (confirmed by the 95-minute outage trace) — but it's about the accuracy of the board's liveness check, not about false `repeated_failure` alerts, sustained-outage detection, or recovery announcements. None of the ticket's required outcomes depend on it:

- No false alarms for isolated probes → fixed by signal.py alone.
- Sustained outage reported once within ~10 min → fixed by signal.py + #1 above.
- Recovery announced → already works today (`test_responder_announces_recovery` passes against current `responder.py`); nothing about the new signal requires changing how recovery is detected.

"Where necessary" in the issue asks the implementer to *establish* need, not to adopt whatever the discovery pass turned up. Repeating the claim across the discovery and planning comments doesn't settle it either. If Michael wants the board-liveness bug fixed, that's a reasonable but separate decision — and it carries real ongoing cost beyond this ticket's size: a second state schema version, in-memory upgrade logic, a v1 file left permanently on disk alongside v2 (per the plan: "leaves the v1 file in place"), a new `open_incidents` field whose content duplicates what the render/digest already track, and a new CI job (`lint`/`unit`/`docs` → +1) that exists to validate a JSON file with exactly one reader (`board.py`) and one writer (`responder.py`). That's a lot of permanent ownership to take on to fix a board-display bug incidentally found while investigating something else.

**Recommendation:** present the board-liveness bug to Michael as a separate, explicit decision: fix it now (accepting the state-versioning/migration/CI cost), defer it, or fix it more cheaply (e.g., have `run_once` always write `last_assessed` to the *existing* state file as one extra field, with no schema version, no migration, no CI job — since the file has exactly one reader and one writer today, a plain additive field needs no versioning ceremony). If deferred or solved minimally, the smallest change for this ticket is just `signal.py` plus the digest-stability fix in #1 — no responder/board changes at all.

This needs a decision before implementation; it is an ownership/component expansion (new persistent schema + migration + CI job), not a routine implementation choice.

### 3. `open_incidents` is unmotivated on its own evidence

Even if the responder split goes ahead, the plan's own rationale for `open_incidents` — "for recovery wording" — isn't demonstrated to require new state. Recovery wording today comes from the render diff (alerts list → empty → "All clear"), which already works per the existing test. If `open_incidents` is only to support the assess/publish split's internal bookkeeping, that's fine as an implementation detail *within* that redesign; it shouldn't be treated as independently required by this ticket. This is secondary to #2: resolve whether the responder redesign happens at all before deciding what state it needs.

---

**Summary for implementation:** the signal fix is sound in direction; fix the count/digest-stability gap (#1) as part of implementing it. Do not fold the responder/state-v2/CI-schema work into this ticket on the strength of "where necessary" — take that to Michael as a separate scoping decision (#2), and let it settle before touching `open_incidents` (#3).