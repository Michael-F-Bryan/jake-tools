# Review: SYN-705 (subtle variant)

**Implementable with specific corrections — the signal fix is ready as scoped; the responder/state portion is not, and needs a decision before implementation.**

## 1. Signal fix — accept as the right, minimal correction

Replacing the windowed count (`signal.py`'s `repeated_failures`) with a "most recent 3 rows all failed" check is well-targeted: the discovery evidence (7/9 alerts had successes interleaved between failures; the 2 genuine outages were consecutive) maps directly onto this rule, it preserves "reported within ~10 minutes" (3 consecutive 1-minute probes = 3 minutes), and it removes the false positives without inventing new machinery. No objection here.

## 2. Blocking ambiguity: what does `Alert.count` mean after the fix, and does the report stay stable?

The plan never pins this down, and it determines whether the rest of the responder redesign is solving a real problem or an imagined one.

- If `count` is fixed (e.g., always `3`, or omitted) once the consecutive-failure condition is met, the rendered report (`REPEATED FAILURE {target} x{count}`) stays byte-identical for the whole outage. The existing digest-equality check in `run_once` already suppresses reposts, and "reported once" holds with no new mechanism.
- If `count` keeps growing with the outage (e.g., consecutive-run length, which is the more natural reading of "replacing the windowed count" with a running tally), the rendered text changes every minute, the digest changes every minute, and `run_once` posts every minute for the whole outage — which already breaks "reported, once" today, not just the board-silence symptom.

This isn't a stylistic nit: it decides whether `open_incidents` (section 3 below) is actually necessary to make "reported once" true, or whether it's solving a problem the fixed-digest behavior already solves. The plan's own tests don't resolve it — "assess/publish with an unchanged report" tests an already-unchanged report, not whether a live multi-minute outage *stays* unchanged under the new signal.

**Recommendation:** Before implementing the responder changes, pin down and test that a simulated N-minute consecutive-failure sequence (N > 10) produces exactly one post under the new signal. This is a bounded investigation, not a redesign — but it has to happen first because it changes which responder mechanism (if any) is required.

## 3. The responder redesign is a larger commitment than the demonstrated bug needs

The demonstrated bug (confirmed by discovery while tracing the real 95-minute outage, not speculative) is: `board.py`'s `responder_status` reads `last_seen`, which `run_once` only writes on `DELIVERED`, so a stable unchanged report for >30 min falsely shows "responder silent."

```python
def run_once(now: datetime) -> Outcome:
    ...
    if digest == state.get("last_digest"):
        return Outcome.UNCHANGED                 # nothing written  <-- the actual bug
    post_to_channel(...)
    save_state({"last_digest": digest, "last_seen": now.isoformat(), "acknowledged": True})
```

The fix for *that* is: write the "we checked" timestamp every call, independent of whether a post happened.

```python
def run_once(now: datetime) -> Outcome:
    report = render(signal.repeated_failures(load_rows(), now))
    digest = sha256(report.encode()).hexdigest()
    state = load_state()
    state["last_checked"] = now.isoformat()      # always written
    if digest == state.get("last_digest"):
        save_state(state)
        return Outcome.UNCHANGED
    post_to_channel("#ops-alerts", report)
    state["last_digest"] = digest
    state["acknowledged"] = True
    save_state(state)
    return Outcome.DELIVERED
```

`board.py` reads `last_checked` instead of `last_seen`. No new file, no `schema` field, no v1→v2 upgrade path, no `open_incidents`.

What the full plan adds beyond this: a `schema` version field, an in-memory v1→v2 upgrade routine, a v1 file left on disk permanently ("leaves the v1 file in place" with no stated cleanup — an orphaned file future maintainers will have to recognize as dead), and **a new CI job that validates `responder_state_v2.json` against a checked-in `schema.json` on every PR touching `state/`.** That CI job is a standing operational cost on all future state changes, for a file with exactly one producer and one consumer in the same process (`responder.py` writes, `board.py` reads `last_seen`/`last_checked` — confirmed in the code excerpts, no other consumer exists). The plan justifies it as "so future state changes are caught," which is guarding against a hypothetical future problem, not the demonstrated one.

**This is a new CI job and a persistent-state migration scheme — both are called out explicitly as things that need Michael's decision, not defaults an implementer or agent comment can settle.** The discovery comment's "recommendation carried forward" that state "should be versioned" is one agent's opinion, repeated into the plan; it isn't a requirement and shouldn't be treated as settled.

**Recommendation:** Decision needed from Michael: adopt the single-field fix above (smallest correction, no new CI job, no schema file, no migration), or explicitly accept the versioning/CI machinery as new scope with its own justification (e.g., an anticipated second consumer of this state, which hasn't been named). Absent that justification, I'd expect the smaller fix.

## 4. `open_incidents` — unproven necessity, likely drop

The plan adds `open_incidents` "for recovery wording," but no defect involving recovery wording was found in discovery — the 9-alert sample doesn't surface a multi-target concurrent-incident case, and the existing `render()`/digest mechanism already announces recovery correctly for the single-outage-at-a-time pattern evidenced in the ticket (report becomes `"All clear..."`, digest changes, post fires; `test_responder_announces_recovery` already covers this). If `count` turns out to be stable per Concern 2, `open_incidents` has no remaining job to do.

**Recommendation:** Drop it unless Michael can point to a concrete concurrent-incident scenario that needs per-target recovery text; if he can, that's a feature addition to scope explicitly, not a side effect of the responder-silence fix.

## Net

- Ship the signal fix (section 1) — ready.
- Resolve the `count`/stability question (section 2) before writing any responder code — bounded, fast.
- Replace the schema-versioned state + migration + CI job with the single added field (section 3), or get Michael's explicit sign-off on the larger version if there's a reason for it I'm not seeing.
- Drop `open_incidents` pending a concrete need (section 4).