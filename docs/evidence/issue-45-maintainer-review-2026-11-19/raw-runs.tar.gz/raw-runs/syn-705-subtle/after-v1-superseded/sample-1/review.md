**Implementable with specific corrections.** The signal fix (Part 1) is sound and ready as proposed. The responder/state rework bundled in as Part 2 is a much bigger change than the defect it's fixing, and the extra pieces (schema versioning, migration, a new CI job, `open_incidents`) need Michael's explicit decision before they're built — they aren't required by this ticket and shouldn't be accepted just because the plan asserts they're "necessary."

## Part 1 — signal fix: ready

Replacing the windowed count with "most recent 3 rows consecutive" is well evidenced (7/9 recent alerts had interleaved successes and shouldn't have fired; the 2 genuine outages were consecutive) and satisfies both "must keep working" constraints. This is the smallest intervention for the reported problem and I don't see a reason to expand it.

One detail worth pinning down during implementation, not blocking: the plan doesn't say what `Alert.count` becomes once the new rule is true. If `count` tracks the length of the consecutive run rather than staying fixed at the threshold, the rendered report changes every probe for the whole outage (3, 4, 5, …, 95), the digest never repeats, and the responder posts every minute for a 95-minute outage — which both breaks "reported, once, within about 10 minutes" and reintroduces the exact noise this ticket exists to remove. The plan's own framing (treating a sustained outage as an "unchanged recurrence") only holds if `count` is pinned once the threshold is crossed. Recommend pinning it and adding a test that a sustained outage past the threshold produces an unchanged digest.

## Part 2 — responder rework: disproportionate to the defect

**The actual bug, and the minimal fix for it.** `board.py` reads `last_seen`, which `responder.py` only writes on a post:

```python
if digest == state.get("last_digest"):
    return Outcome.UNCHANGED                 # nothing written
```

Once the signal fix lands, a real sustained outage becomes stable after its first post, so `UNCHANGED` becomes the normal steady state for a genuine incident — and after 30 minutes the board will say "responder silent" about a responder that's working correctly. I agree this is a legitimate reason to touch the responder, satisfying the ticket's "where necessary" clause.

But fixing it doesn't require `assess`/`publish` separation, a `schema: 2` field, an in-memory v1→v2 upgrade that leaves the old file in place forever, or a third CI job. It requires `last_seen` to advance on every call:

```python
def run_once(now):
    report = render(signal.repeated_failures(load_rows(), now))
    digest = sha256(report.encode()).hexdigest()
    state = load_state()
    changed = digest != state.get("last_digest")
    if changed:
        post_to_channel("#ops-alerts", report)
    save_state({"last_digest": digest, "last_seen": now.isoformat(),
                "acknowledged": state.get("acknowledged", True)})
    return Outcome.DELIVERED if changed else Outcome.UNCHANGED
```

Same file, same schema, same `board.py` contract — no version field, no migration, no new CI job. The rejected design is new permanent infrastructure (a schema file that has to be kept in sync by hand, a migration with no stated removal date, a third CI job gating every PR that touches `state/`) for what's otherwise a one-field write-timing fix. That's a meaningful increase in what the team owns and debugs going forward, and it needs Michael to decide he wants it — it shouldn't ride in as an implementation detail of the signal fix.

**`open_incidents` is an unrequested feature riding on the same rework.** The ticket only requires "recovery from a reported outage is still announced," which already works today: `render([])` → "All clear: no repeated failures," digest changes, `run_once` posts it (`test_responder_announces_recovery` already covers this). `open_incidents` exists so recovery wording can name the specific target instead of saying "All clear" — a nicer message, but not what's asked for, and it adds state whose consistency with what was actually posted (vs. merely assessed) now has to be maintained. Recommend dropping it unless Michael wants the more specific wording as an explicit, separate requirement.

**If the versioned-state design is kept anyway**, leaving the v1 file in place indefinitely after an in-memory upgrade should at least be justified or replaced with a cleanup step — "two state files forever" is maintenance debt with no stated purpose.

## Summary

- Ship the signal fix as planned (pin `Alert.count`, confirmed during implementation).
- Fix `board.py`'s "silent" false positive with the minimal always-write-`last_seen` change above.
- Cut `schema: 2`, the v1→v2 migration, `open_incidents`, and the new CI schema job from this change — reintroduce them only if Michael decides he wants that capability, as a separate decision with its own justification.