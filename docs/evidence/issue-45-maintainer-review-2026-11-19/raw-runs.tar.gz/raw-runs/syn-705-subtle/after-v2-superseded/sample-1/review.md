# Review: SYN-705 (subtle variant)

**Judgement: Implementable with specific corrections.** The signal fix is the right, small change and should proceed. The responder/state-v2/CI piece is a material scope expansion bundled into this ticket without establishing that it's required by the ticket's actual acceptance criteria, and should be decoupled for Michael's decision before implementation.

## 1. The responder redesign is scope expansion, not a correction "where necessary" (decision needed)

The issue's only behavioural requirements are:
- a sustained outage is still reported once within ~10 minutes, and
- recovery from a reported outage is still announced.

Looking at `responder.py` as it stands today, **both already hold once the signal is fixed**, with no responder change at all: `run_once` posts when the digest changes (alert appears → posts; outage ends → digest flips to the "All clear" render → posts). The consecutive-failure signal change doesn't touch this path.

The plan instead proposes: splitting `run_once` into `assess`/`publish`, a new state schema (`schema: 2`, `open_incidents`), an in-memory v1→v2 upgrade that leaves the v1 file in place indefinitely, a `board.py` change, and a new CI job that validates `responder_state_v2.json` against a checked-in JSON schema on every PR touching `state/`.

The stated justification is the board-silence bug found in discovery ("responder silent" shown after 30 minutes of an *unchanged* outage because `last_seen` is only written on post). That's a real, separate defect — but it's pre-existing and orthogonal to the alert-noise problem the issue describes; it isn't mentioned in "must keep working," and the plan's own evidence (discovery comment) shows it would exist today independent of this fix. Citing "where necessary" to justify it inverts the instruction: the ticket asks us to *establish* necessity, not treat the discovery as license to redesign the responder's state model.

This is exactly the kind of addition that needs Michael's sign-off rather than being folded into implementation: it adds persistent state (schema v2 fields), a migration (v1 kept alongside v2 with no cleanup path — a second maintainer now has to know which file is authoritative), and an operated CI job (a schema file plus a PR-gating validation step) for a two-field state file with a single writer and single reader (`board.py` reads only `last_seen`, per the discovery comment — no other consumer exists).

**If** the board-silence bug is judged worth fixing now, the smallest correction is far narrower: write `last_seen`/`last_assessed` unconditionally in `run_once`, in the existing `state/responder_state.json` format, with no version field, no migration, and no new CI job:

```python
def run_once(now):
    report = render(signal.repeated_failures(load_rows(), now))
    digest = sha256(report.encode()).hexdigest()
    state = load_state()
    state["last_seen"] = now.isoformat()          # always updated
    if digest == state.get("last_digest"):
        save_state(state)
        return Outcome.UNCHANGED
    post_to_channel("#ops-alerts", report)
    state.update(last_digest=digest, acknowledged=True)
    save_state(state)
    return Outcome.DELIVERED
```

This fixes the board symptom the discovery comment actually found, without introducing a schema version, a dual-file migration, or a new CI job to maintain. **Recommend:** present the board-silence fix to Michael as an optional, separately-scoped addition (small version above), and drop the v2 state/migration/CI-schema slice from this ticket unless he decides the versioned-state investment is wanted for reasons beyond this bug.

## 2. `open_incidents` is an unrequested addition to the same state

The plan adds an `open_incidents` list "for recovery wording," but the existing render/digest mechanism already produces and posts an "All clear" report on recovery (`test_responder_announces_recovery` already exists and the issue's recovery requirement is already satisfied this way). No concrete recovery-wording requirement in the issue needs per-target incident tracking. Recommend dropping this field unless a specific wording requirement is identified — it's additional hidden state whose need hasn't been shown.

## 3. The signal fix itself is sound and is the right size

Replacing the 15-minute windowed count with "most recent 3 rows for the target are all failures" directly targets the diagnosed cause (discovery: 7 of 9 alerts were non-consecutive failures with recoveries in between) and the discovery comment confirms both genuine outages still alert within 3 minutes — comfortably inside the "about 10 minutes" requirement. This is the smallest credible intervention for the reported problem and I'd accept it as-is; the planned tests (consecutive, interleaved, boundary) cover the right cases.

One implementation detail worth the implementer's attention, not a blocker: dropping the time window means "most recent 3 rows" has no recency bound built in. If probing for a target can pause for a long time and later resume, confirm this doesn't let 3 stale failures from before a gap read as current — the discovery data doesn't rule this in or out, but it's a cheap thing to cover in the boundary test rather than a reason to hold the change.