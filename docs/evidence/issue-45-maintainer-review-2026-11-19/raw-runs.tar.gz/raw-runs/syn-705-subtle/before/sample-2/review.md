**Judgement: Blocked on a decision for part of this plan — the signal correction (Slice 1) is ready to implement on its own; Slices 2 and 3 (the responder redesign) should not proceed as "necessary" without Michael confirming scope.**

## 1. The responder redesign is justified by a bug the ticket never raised, and isn't required by anything the ticket does ask for

The issue asks for the smallest correction to `repeated_failures` plus responder changes "where necessary" to support it. The discovery comment separately found, while investigating billing-api's 95‑minute outage, that `board.py` shows "responder silent" after 30 minutes of an *unchanged* report, because `run_once` only writes `last_seen` on `DELIVERED`. The planning comment then treats fixing this as mandatory for this ticket:

> "the board bug and the limitation above make this [responder change] necessary"

But check that against the ticket's own acceptance criteria:
- *"a genuinely sustained outage is still reported, once, within about 10 minutes"* — satisfied by `signal.py` alone: 3 consecutive 1‑minute rows trip the new rule at minute 3, and `run_once` already posts once and then returns `UNCHANGED` on subsequent identical reports.
- *"recovery from a reported outage is still announced"* — also satisfied unchanged: when the target recovers, `render()` returns a different string ("All clear…"), the digest changes, and `run_once` posts it. No `responder.py` edit needed.

So the two things the ticket explicitly protects don't require any `responder.py` change at all. The board's "silent" status isn't mentioned in the issue, isn't one of the "must keep working" items, and wasn't reported by on-call — it was discovered incidentally while root-causing something else. Bundling a versioned state schema (`responder_state_v2.json`), an assess/publish split, an `open_incidents` field, and a new CI schema-validation job into this ticket on the strength of "where necessary" stretches that clause past what the evidence supports.

**Recommendation:** Ship Slice 1 (the signal fix) as the actual response to this ticket. Raise the board-silence gap as a separate proposal for Michael to decide on its own merits (it's a real bug, just not this ticket's bug) — not as an automatic consequence of fixing the signal. **Needs a decision before Slices 2–3 are built.**

## 2. "Reported once" isn't verified for the new signal — a growing count could repost every minute

The new rule is "most recent 3 rows are all failures," but `Alert` still carries a `count: int`, and neither the discovery nor the plan says what that count *is* once a target is past the 3-row trigger. If the implementation keeps incrementing it for as long as the outage continues (the natural reading of "count of consecutive failures"), then `render()`'s output — `REPEATED FAILURE {target} x{count}` — changes every probe cycle for the whole outage. Since `run_once` dedupes by hashing that exact string, a changing count means a changing digest means a repost every minute for the full 41- or 95-minute outage, not once.

That directly contradicts the "must keep working: reported, **once**" requirement — the same category of alert fatigue this ticket exists to remove, just now applied to real outages instead of flaky ones.

The planned tests ("consecutive, interleaved, boundary" for the signal; "assess/publish with an unchanged report… no post" for the responder) don't include a case that pins the report/digest stable across multiple consecutive failing probes beyond the third. Nothing in the plan commits to that stability.

**Recommendation:** Specify that the alert representation (whatever `count` means) is stable for the duration of a sustained outage — e.g., cap it at the threshold, or drop it from the rendered text — and add a test asserting the digest is unchanged on the 4th, 5th, … consecutive failing probe. This is a correction to Slice 1's design, not a new responder feature, and **can be incorporated during implementation.**

## 3. If the responder redesign is pursued anyway, the v1→v2 field rename is a deployment hazard, not a detail

`board.py` and `responder.py` are described as independent consumers of one file ("only `responder.py` writes… only `board.py` reads… no other consumer exists"), which implies they can be deployed separately. The v2 schema drops `last_seen` entirely in favor of `last_assessed`. If `responder.py` ships first and writes a v2 file, any `board.py` still running the old code does:

```python
seen = datetime.fromisoformat(state["last_seen"])   # KeyError: 'last_seen' is gone
```

The plan's "load_state() upgrades v1 in memory" protects the *responder* from old files; it does nothing for an *old board* reading a new file. This is exactly the kind of boundary-compatibility question the plan needs to answer and currently doesn't.

**Recommendation, conditional on Michael deciding to do the redesign at all:** either keep writing `last_seen` alongside `last_assessed` through the transition, or make `board.py`'s read tolerant of the missing key, and say which. **Would need to be resolved before implementing Slices 2–3**, not discovered in review of the PR.

## Minor, non-blocking

The plan leaves the v1 state file in place forever after the first v2 write ("creates v2 and leaves the v1 file in place"). Nothing reads it afterward. That's a small bit of dead state a future maintainer will eventually trip over wondering which file is authoritative. Worth a one-line cleanup note if Slices 2–3 go ahead, but not a reason to hold up anything.

---

**Summary:** The signal diagnosis itself is solid and well evidenced (30 days of alert history, clear separation of the 7 false positives from the 2 genuine outages) — that part is ready to implement, with the count/"once" stability gap called out above folded in. The responder redesign is a separately-motivated fix for a real but out-of-scope bug; it should go to Michael as its own proposal rather than ride in under "where necessary."