**Review of SYN-705 (subtle variant) — plan at `a1b2c3d`**

**Judgement: Implementable with specific corrections.** The signal fix (Part 1) is sound, evidence-backed, and ready as written. The responder/state work (Part 2 + Part 3) should not proceed in its current form — it has an unresolved detail that could actually regress the "reported once" requirement, and the fix it does deliver is heavier than the demonstrated need. Flagging that prominently because it's most of the planned diff.

---

**1. `Alert.count`'s meaning under the new rule is unspecified, and the two plausible readings each break something**

The plan says `repeated_failures` now alerts "when a target's most recent 3 rows are all failures (consecutive)," but `Alert` still carries a `count` field, and `render()` puts that count in the posted text (`REPEATED FAILURE {target} x{count}`). The plan never states what `count` is once the rule is no longer "count in window."

- If `count` continues incrementing for every consecutive failing row (4, 5, 6, …) for as long as the outage lasts, the rendered report changes every single probe cycle during a genuine outage. `responder.run_once` posts whenever the digest changes, so a long outage (e.g., the 95-minute `billing-api` case used as the evidence base) would produce a new `#ops-alerts` post every minute for 95 minutes — not "reported once," which is an explicit must-keep-working requirement.
- If `count` is instead frozen once the threshold trips (e.g., always rendered as the fixed text once ≥3 consecutive), the report is static for the rest of the outage, and the pre-existing "report unchanged → no write → board sees `last_seen` go stale → reports 'responder silent'" problem (discovery's finding) reproduces exactly as before, just with a different trigger condition. In that case Part 2 is still addressing a real defect, but its necessity needs to be re-argued from that premise, not asserted independently.

This also determines whether Part 2 is solving something the Part 1 fix already changes the shape of. It should be settled before either Part 1's render output or Part 2's design is finalized — not left as an implementation detail, since it decides whether the "must keep working: reported once" bar is met at all.

*Recommendation:* Pin `count` semantics explicitly (e.g., "count is capped/reported as the run length but the report text for an ongoing outage must not change on an unrelated increment" or similar), and add a test asserting a single genuine outage produces exactly one post over its duration. This blocks sign-off on the signal change as currently described, not just the responder piece.

---

**2. The responder fix, if the board-silence case is confirmed real, is bigger than the need it addresses**

The board-silence issue is real — discovery traced it against the actual 95-minute `billing-api` outage, not a hypothetical. The issue text's "change responder behaviour where necessary" plausibly covers fixing it here. But the proposed mechanism is disproportionate to a single-consumer, single-writer state file:

- A new schema version (`schema: 2`), in-memory upgrade path for v1, and writing to a *new file* (`responder_state_v2.json`) while "leaving the v1 file in place" indefinitely — current code: `STATE = Path("state/responder_state.json")` with 3 keys, read only by `board.py`'s one field (`last_seen`). There's no second consumer and no compatibility requirement driving a file rename or version field.
- A new checked-in JSON schema (`state/schema.json`) plus a dedicated CI job gating every PR that touches `state/` — for a file that today has three keys and one reader.

The actual gap is narrower: `run_once` needs to record "I looked" independently of "I posted." That's addable as one more field in the existing file, written unconditionally on every call, with no version bump, no file split, and no schema-validation CI step:

```python
def run_once(now):
    report, digest = ...
    state = load_state()
    state["last_checked"] = now.isoformat()
    if digest != state.get("last_digest"):
        post_to_channel(...)
        state["last_digest"] = digest
        state["last_seen"] = now.isoformat()
    save_state(state)
```

`board.py` then reads `last_checked` instead of `last_seen`. This keeps the same file, the same consumers, and no migration logic, at a fraction of the surface area.

*Recommendation:* Drop the schema versioning, the v1/v2 file split, and the CI schema-validation job (Slice 3) unless Michael has a specific future-consumer reason for them that isn't in the ticket. Implement the unconditional-timestamp version instead. This can be done during implementation once concern 1 is resolved — it doesn't need a separate decision round, but Slice 3 specifically should be confirmed as in/out of scope since it's process overhead the ticket doesn't ask for.

---

**3. `open_incidents` isn't tied to a demonstrated gap**

The plan adds `open_incidents` ("list of targets currently reported, for recovery wording") without explaining what's currently wrong with recovery announcements. The existing mechanism already announces recovery: when all alerts clear, `render()` returns `"All clear: no repeated failures."`, which differs from any prior alert digest and triggers a post — and `test_responder_announces_recovery` already exists and (per the discovery/planning comments) isn't reported as broken. The "must keep working" bar is just "recovery … is still announced," which the current mechanism satisfies.

If `open_incidents` is meant to produce per-target wording (e.g., "billing-api recovered" vs. a generic all-clear when multiple targets are involved), that's a new capability, not a requirement in the ticket or the discovery findings.

*Recommendation:* Either cite the concrete case `open_incidents` fixes (e.g., "today, target A recovering while B is still failing produces no visible recovery signal for A — here's the alert history example") or drop it from this ticket. This is a question for Michael if the richer wording is actually wanted; otherwise it can simply be omitted during implementation without any loss against the stated requirements.

---

**What's settled and doesn't need to be revisited**

- The signal rule itself (3 consecutive rows, not a windowed count) is correctly scoped to the reported symptom, and the discovery comment's historical check (2/2 genuine outages still catch within 3 minutes, 7/7 false positives eliminated) is real evidence, not a hypothetical — no objection to the rule itself, only to the unspecified `count` field it still carries (concern 1).
- Separating "assessed" from "published" as a concept is the right shape for the board-silence problem once/if that problem is confirmed to survive the signal fix — the objection is to the versioned-file mechanism chosen to implement it (concern 2), not to the assess/publish idea.