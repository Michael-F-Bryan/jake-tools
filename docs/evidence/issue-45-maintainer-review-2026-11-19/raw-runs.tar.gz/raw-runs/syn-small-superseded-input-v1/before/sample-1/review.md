**Issue:** synthetic-case:syn-small — `Retry-After` given as an HTTP date crashes the client

**Judgement: Implementable with specific corrections.**

The problem framing is sound and the plan doesn't overreach: the bug is real (RFC 9110 permits HTTP-date, `_delay` only handles delay-seconds), the fix is scoped to the one call site (`grep` confirms `_delay` has no other callers per the discovery comment), and the decision to treat unparseable/past dates as "retry now" rather than propagate an exception is a reasonable reading of "a malformed header from a server should not turn into a client crash." Retry count and `MAX_DELAY` are correctly left out of scope — no reason to reopen that. The two corrections below are about whether the implementation as sketched actually delivers the "never crash on a bad header" guarantee the plan promises, not about redesigning anything.

---

**1. The no-crash guarantee can fail exactly on malformed input, which is the case this issue exists to fix.**

The plan says: "HTTP date in the past, or an unparseable value: `0` ... rather than raising." That's the right behaviour, but `email.utils.parsedate_to_datetime` doesn't fail in one consistent, easy-to-catch way:

- On Python < 3.10, an unparseable string makes the underlying `parsedate_tz` return `None`, and `parsedate_to_datetime` then raises `TypeError` (not `ValueError`) trying to subscript `None`.
- Even on a parseable date, if the header omits timezone info (a real-world malformed variant, not the clean `GMT`-suffixed example in the issue), `parsedate_to_datetime` can return a *naive* datetime. Subtracting that from an aware `now` (e.g. `datetime.now(timezone.utc)`) raises `TypeError: can't subtract offset-naive and offset-aware datetimes` — a second, different crash.

So "except ValueError" alone — the natural reading of the plan's wording — does not fully cover "unparseable value," and the fix could still crash on a header that is malformed in a slightly different way than the one in the bug report. That defeats the stated purpose.

- Recommendation: catch broadly enough to cover both parsing failure and the aware/naive mismatch (e.g. `except (ValueError, TypeError)` around the whole parse-and-subtract, or normalize any naive result to UTC before subtracting), and add one test case using a timezone-less or otherwise oddly-malformed date string (not just a clean unparseable string) to lock in that the broader failure mode is actually caught.
- This is a correction to make during implementation, not a design decision needing Michael's input — but it should be called out explicitly because the plan's current wording ("unparseable value: 0") understates how many ways parsing can fail.

**2. The `now` default argument, if written the obvious way, goes stale for the life of the process.**

The plan says `_delay` "gains an optional `now` argument defaulting to the current UTC time." The natural way to write that —

```python
def _delay(value: str, now: datetime = datetime.now(timezone.utc)) -> int:
```

— evaluates the default once, at function-definition time (import time), not per call. Every subsequent call to `_delay` with an HTTP-date header would compute `parsed_date - now` against a `now` that is frozen at process startup. In a long-lived process, this silently drifts: the computed "seconds until the date" grows stale and increasingly wrong (and, depending on direction, could make a currently-valid future date look like it's already passed, collapsing the retry delay to `0` when it shouldn't be). No test in the plan would catch this, since tests pass `now` explicitly.

- Recommendation: use a sentinel default (`now: datetime | None = None`) and resolve `now = now or datetime.now(timezone.utc)` inside the function body, so each call gets the real current time while still allowing tests to inject a fixed one.
- This is a correction to make during implementation; it doesn't change the plan's intended behaviour or test coverage, just how the optional parameter should be wired up.

---

No other concerns. The stdlib-only approach, the cap/rounding behaviour, the fallback-to-`0` policy for bad headers, and the decision not to touch the retry loop are all appropriate and don't need rework — they just need the two implementation details above to actually hold.