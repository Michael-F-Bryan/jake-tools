**Judgement: Implementable with specific corrections.**

The core diagnosis and mechanism are sound: the stack trace and upstream behaviour are real, RFC 9110 genuinely allows both `delay-seconds` and an HTTP-date, and `_delay` is confirmed (via grep) to be the only parser of this header with only two callers (`get` and its own tests). Extending `_delay` in place — no new class, no header-parsing module, no change to the retry loop — is the right-sized response; there's no abstraction here worth inventing for a single call site. The `now` parameter for testability is a reasonable, minimal addition to a private function and doesn't leak into the public interface.

Three points need tightening before/while implementing, ordered by how much they threaten the fix's actual goal (not crashing on a malformed/unexpected header):

**1. The fallback must not rely on catching only `ValueError` — it can still crash.**

The plan says "unparseable value → 0 ... rather than raising," but `email.utils.parsedate_to_datetime` doesn't reliably raise `ValueError` for bad input across Python versions: before 3.10 it can raise `TypeError` instead for strings it can't parse at all. Separately, even when parsing succeeds, if the header lacks a recognizable zone (not all "HTTP-date-ish" strings a flaky upstream sends will include a proper `GMT`/offset), `parsedate_to_datetime` can return a *naive* datetime; subtracting that from an aware `now` raises `TypeError: can't subtract offset-naive and offset-aware datetimes` — i.e. exactly the kind of uncaught exception this fix exists to eliminate, just with a different message than the one in the issue.

Concretely: `Retry-After: not-a-date` or a malformed date missing a zone can still produce an uncaught `TypeError` under this plan if the implementer (reasonably, given the issue's own traceback is a `ValueError`) only catches `ValueError`.

Recommendation: wrap the whole "try int, else parse as date, else 0" logic in a single `try/except (ValueError, TypeError):` returning 0, rather than assuming the stdlib call's failure mode is uniform. This is a one-line implementation correction, not a design change — safe to fold in during implementation, no decision needed.

**2. "Unparseable → 0 (retry immediately)" may defeat the backoff the issue is about.**

The issue's complaint is "requests that should have backed off... fail outright." The fix makes a past-dated `Retry-After` return 0, which is correct per RFC semantics (the wait has already elapsed). But it also maps a genuinely garbled, unparseable value to 0 — i.e. *no* backoff at all — against a server that just told you (402/503) it's overloaded. That's a different outcome from today's default: when the header is *absent*, `get` already falls back to `"1"` (one second), not 0. So a malformed header would now cause faster retries than no header at all, on exactly the servers least able to take it.

This is a one-line behavioural choice, not a crash risk, so it doesn't block implementation, but it's worth Michael confirming explicitly: should "unparseable" fall back to the same default used for a missing header (`1`, capped as today) instead of `0`, keeping `0` reserved for the "date already passed" case where immediate retry is actually what RFC 9110 implies? I'd flag this as a proposed revision to the plan's stated behaviour table, not a correction you should silently make.

**3. The plan's own "malformed header shouldn't crash" principle isn't applied to negative integers, on the same line being edited.**

`Retry-After: -5` parses fine as `int("-5") = -5`, `min(-5, 60) = -5`, and then `time.sleep(-5)` raises `ValueError: sleep length must be non-negative` inside `get` — the same user-visible crash the issue reports, just via a different malformed value than the one in scope. The discovery comment marks "retry count and `MAX_DELAY`" as out of scope, but doesn't mention negative delay-seconds, and this plan is already touching this exact return statement and already adopting "malformed input shouldn't crash" as its rationale for the date-parsing branch.

This isn't required by the issue title, so I'm not asserting it must be fixed here — but since it's the same function, same failure symptom, and a one-line `max(0, ...)` on the existing integer path, it's worth a quick decision: close it in this change for consistency, or explicitly note it as a known, separately-tracked gap so a future reader doesn't assume "handle both forms" also means "no malformed value can crash the sleep call."

**Verification:** the proposed table-driven test set (integer unchanged, future date under/at cap, past date, unparseable) is adequate for a change this narrow — I wouldn't ask for end-to-end retry-loop coverage beyond what already exists. I'd just add: a case with a date string that parses but lacks a timezone (to exercise the naive/aware subtraction path in point 1) and a case for `Retry-After: -5` if point 3 is taken on.

None of this reopens the settled scope ("handle both forms," no retry-loop changes) — it's about making the "don't crash on malformed input" guarantee the plan itself proposes actually hold.