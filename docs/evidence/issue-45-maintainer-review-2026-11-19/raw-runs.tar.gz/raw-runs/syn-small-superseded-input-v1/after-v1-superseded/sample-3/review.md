**Implementable with specific corrections.**

The proposed scope is right-sized: this is a single-function fix with no new dependency, no API surface change beyond an optional `now` kwarg for testability, and no touch to the retry loop or the existing `MAX_DELAY`/retry-count decisions (correctly treated as settled and out of scope). A narrower "catch the exception and return a constant" fix was considered and correctly rejected — the issue isn't just "don't crash," it's "handle both forms," i.e. actually honor the server's requested wait when it's expressed as a date. So computing seconds-until-date is the right amount of mechanism, not over-engineering. I have one concrete correction that should land before this is merged.

**Correction: the "unparseable value → 0" guarantee isn't actually met by the described exception handling**

The plan's contract is explicit: *"HTTP date in the past, or an unparseable value: `0` … rather than raising. A malformed header from a server should not turn into a client crash."* That's exactly the guarantee this fix exists to provide.

The natural implementation is:

```python
try:
    return int(value)
except ValueError:
    pass
try:
    dt = parsedate_to_datetime(value)
except ValueError:
    return 0
...
```

The problem is `email.utils.parsedate_to_datetime`'s failure mode for a genuinely malformed string (e.g. `Retry-After: garbage`) is not reliably `ValueError`. Internally it unpacks the result of `_parsedate_tz`, which returns `None` for unparseable input; depending on the stdlib version, that either raises `TypeError` (from unpacking `None`) or is translated to `ValueError`. If the implementation only catches `ValueError` here, a header that is neither a valid integer nor a valid HTTP date reproduces the exact crash this issue is filed to fix — just via `TypeError` instead of the original `ValueError`, and possibly only on some Python versions, so it could pass locally and fail elsewhere.

Consequence: the fix would close the reported case (HTTP-date header) but leave open a sibling crash on any other malformed `Retry-After` value, under the same "server sends bad header, client should not crash" promise the plan makes.

Correction (implementable now, no decision needed): catch both `ValueError` and `TypeError` around the date-parsing fallback (or wrap the whole fallback path in a single broad `except`), and make sure the planned test for "unparseable value" uses a string that is neither a valid int nor anything `_parsedate_tz` can partially parse — not just a syntactically-close-but-wrong date — so the test actually exercises this path rather than one that happens to parse into *some* datetime.

No other concerns: the discovery's confirmation that `_delay` has exactly one caller and two existing tests is sufficient to size this change, and the table-driven test plan (int, future date, past date, unparseable, cap boundary) is adequate verification once the exception handling above is fixed.