**Implementable with specific corrections.**

This is the right-sized fix. The issue explicitly asks to "handle both forms," not merely avoid the crash, so parsing the HTTP-date case (rather than, say, catching `ValueError` and returning a fixed fallback) is the correct scope — a smaller "catch and default" fix would silently ignore the server's requested backoff, which the RFC and the issue both call out as required behaviour. The plan touches one function, adds no dependency (stdlib `email.utils.parsedate_to_datetime`), no new state, and `_delay` has no other callers (confirmed in `04-code-excerpts.md`), so there's no coordination or ownership expansion here. The `now` parameter is an ordinary testability hook, not a new responsibility.

One correctness risk needs to be closed before merge:

**Timezone-naive `now` would reintroduce the exact crash this fix targets.**
- Problem: the plan says `_delay` gains "an optional `now` argument defaulting to the current UTC time," without specifying that it must be timezone-*aware*.
- Evidence: `email.utils.parsedate_to_datetime` returns a timezone-aware `datetime` for a well-formed `Retry-After` date (e.g., the `Wed, 21 Oct 2026 07:28:00 GMT` from the bug report). If the default `now` is produced with `datetime.utcnow()` (naive) instead of `datetime.now(timezone.utc)` (aware), the subtraction `parsed_date - now` raises `TypeError: can't subtract offset-naive and offset-aware datetimes`.
- Consequence: every *valid* future HTTP-date — the normal case this ticket is about — would crash `get` with a different exception than today's `ValueError`. The fix would appear correct in a hand-rolled test that passes its own `now`, while the production path (default `now`) stays broken.
- Recommendation: implement `now` as `datetime.now(timezone.utc)` (or equivalent) and add at least one test that exercises the *default* `now`, not only the injected one, so the aware/naive mismatch can't hide behind the override parameter.
- Status: routine implementation correction, not a decision for Michael — but worth stating explicitly since it's easy to get backwards and the planning comment doesn't mention it.

One smaller point worth a decision, not a blocker:

**Fallback for an unparseable `Retry-After` value is 0 seconds, i.e., retry immediately.**
- The existing code already treats a *missing* header as a 1-second delay (`resp.headers.get("Retry-After", "1")`). The plan has a *present-but-garbage* header fall back to 0, which is a more aggressive retry than the missing-header case right next to it.
- Consequence: a server sending a malformed `Retry-After` on a 429/503 gets hammered immediately instead of backed off — arguably the opposite of what the status code is asking for, though less severe than crashing.
- Recommendation: consider falling back to the same default as the missing-header case (1s) rather than 0, for consistency. This is a one-line behavioural tweak within the chosen approach, not a new mechanism — fine to settle during implementation unless Michael wants it preserved as specified.

No concern with everything else: the cap/floor interaction (explicit 0-floor for past dates, since the current `min(..., MAX_DELAY)` has no lower clamp) is correctly reasoned about, the retry loop and `MAX_DELAY`/retry-count are rightly left untouched, and the table-driven test plan matches the stated cases. (A pre-existing, unrelated gap — the integer branch has no lower clamp either, so a server sending `Retry-After: -5` today would crash `time.sleep`faithfully it already does — is out of scope for this ticket and not worth pulling in here.)