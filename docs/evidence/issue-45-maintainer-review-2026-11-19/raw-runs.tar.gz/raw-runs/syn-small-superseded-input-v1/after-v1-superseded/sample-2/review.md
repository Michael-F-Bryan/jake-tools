**Review of SYN-small**

**Judgement: Implementable with specific corrections.**

The chosen approach — extend `_delay` in place, use the stdlib `email.utils.parsedate_to_datetime`, no new dependency or component — is already the smallest credible intervention for "handle both forms of `Retry-After`." There's no smaller fix that would actually satisfy the issue (a narrower parse-only-seconds fix would leave the reported crash unresolved), and no larger abstraction is warranted: `_delay` has exactly one caller and two tests, so keeping the logic inline is correct. I have no objection to the scope or boundary of the change.

Two concrete implementation details need to be nailed down before this is safe to merge, and one behavioural choice should be confirmed with Michael since it changes how the client behaves under a *new* input class (garbled headers) that the issue itself doesn't describe.

---

**1. Timezone-naive vs. timezone-aware comparison will raise `TypeError`**

`email.utils.parsedate_to_datetime` on a GMT HTTP-date returns a timezone-*aware* `datetime` (tzinfo = UTC) on Python ≥ 3.3 when the date string includes `GMT`. If `_delay`'s `now` default is built with `datetime.utcnow()` (naive), the subtraction `parsed_date - now` raises:

```
TypeError: can't subtract offset-naive and offset-aware datetimes
```

i.e. the exact crash this ticket is meant to eliminate, just moved one line down. The planning comment doesn't specify how `now` is constructed. Correction: default `now` via `datetime.now(timezone.utc)` (or strip/attach tzinfo consistently) so both sides of the subtraction are aware. This is a one-line implementation detail, not a design question — implementer can fix it without a decision from Michael, but it needs to be called out because the table-driven test as described ("date exactly at the cap") will only catch it if the test actually runs the comparison rather than mocking it.

**2. Exception type for unparseable dates is version-dependent**

`parsedate_to_datetime` on a genuinely malformed string raises `TypeError` on Python < 3.10 (it calls `datetime(*None)` internally) and `ValueError` on Python ≥ 3.10. The plan says "unparseable value → 0" but doesn't say which exception(s) `_delay` catches. If only `ValueError` is caught and the deployed Python is older, the fallback path itself still crashes — again reproducing the bug under a different trigger. Correction: catch `(ValueError, TypeError)` around the date-parse attempt, or confirm the minimum supported Python version and document why one is sufficient. Implementable without a decision; just needs to be explicit in the diff.

**3. Falling back to `0` for malformed headers — worth confirming, not blocking**

For a date that has already passed, `0` (retry immediately) is a faithful reading of the server's instruction — fine. But the plan also routes *unparseable garbage* through the same `0` path. The existing code already has a sane default for "no information" (`"1"`, used when the header is absent). Treating "server sent us garbage" the same as "server said retry now" means a malformed `Retry-After` from a server that is *already* returning 429/503 gets hit again with no backoff at all — plausibly worse than the pre-existing crash in terms of load on a struggling upstream, even though it's better in terms of client availability.

This isn't a scope-expanding change (no new state, no new component) and it's a judgement call the implementer could reasonably make either way, so I won't block on it — but since it introduces retry-storm risk that didn't exist before (previously: crash and stop; now: possible tight retry loop), I'd like Michael to confirm `0` is intended for the *unparseable* case specifically, versus falling back to the same `"1"`-equivalent default used when the header is missing. Either answer is implementable as a one-line change; flagging so it isn't decided implicitly by whichever branch the implementer writes first.

---

**Not a concern:** rounding-up and the `MAX_DELAY` cap applying uniformly to both forms match existing behaviour and the issue's intent; the `now` injection parameter for testability is a reasonable, minimal testing seam and doesn't leak into the public `get()` surface. No retry-loop changes are needed, consistent with discovery.

**Summary:** sound, minimal approach; fix the aware/naive datetime comparison and the version-dependent exception type before merging (both implementer-level), and get a quick confirmation from Michael on whether malformed (non-date, non-integer) headers should fall back to `0` or to the existing `"1"` default.