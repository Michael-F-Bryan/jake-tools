**Plan for SYN-705** (builds on the discovery comment)

## Recommendation

Fix the signal and bring the responder in line so that assessing an incident and
publishing about it are separate, with versioned state. This keeps sustained outages
reported exactly once and fixes the "responder silent" board bug found in discovery.

## Design

1. **Classifier.** Add `classify.py`. Each failing target is labelled `isolated`,
   `probe_side` (all 12 targets failed in the same run) or `sustained` (3 consecutive
   failures). Only `sustained` becomes a `repeated_failure` alert. `isolated` and
   `probe_side` get their own counters for later tuning.
2. **Responder state v2.** Replace `{last_digest, last_seen, acknowledged}` with a
   per-incident record `{incident_id, status, first_seen, last_assessed, last_published,
   digest, publish_attempts}` held in `state/responder_state_v2.json`.
3. **Assess vs publish.** Split `run_once` into `assess()`, which always runs and always
   updates `last_assessed`, and `publish()`, fed from a small durable outbox
   (`state/outbox.jsonl`) so a crash between assessment and delivery re-sends exactly one
   report. This resolves the "unchanged recurrence cannot complete without another
   report" limitation.
4. **Migration.** On first run, `migrate_v1_to_v2()` reads the old state file, invents an
   `incident_id` for any open incident, backfills the timestamps and keeps the v1 file as
   `.bak`. Rollback is restoring the `.bak`.
5. **Board.** `board.py` reads v2 and uses `last_assessed` for the silence check.
6. **Verification.** 38 new tests (classifier table, assess/publish ordering, outbox crash
   points, migration fixtures for 6 historical v1 shapes). A new CI job,
   `responder-migration`, runs the migration fixtures against every PR touching `state/`.

## Delivery

Slice 1: classifier and signal. Slice 2: state v2 and migration. Slice 3: assess/publish
split and outbox. Slice 4: board and CI job. Slices 2-4 are tightly coupled.

## Decisions

As agreed in discovery, versioned state is part of this change, and the ticket's
"where necessary" authorises the responder work. No decision is needed from Michael.
