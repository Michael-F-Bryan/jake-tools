**Discovery for SYN-705** (inspected revision `a1b2c3d`, synthetic)

## Conclusion

The over-reporting comes from how `signal.repeated_failures` counts failures: it counts
failed rows per target inside a 15-minute window and alerts at 3, whether or not they
were consecutive. Three unrelated one-off failures in 15 minutes therefore alert.

## Evidence

Last 30 days of `#ops-alerts`: 9 `repeated_failure` alerts.

| Alert | Failures in window | Successes between failures | Duration of real failure |
|---|---|---|---|
| 7 of 9 | 3 | yes, every time | none: target healthy |
| 2 of 9 | 3+ | no | `billing-api` down 41 min and 95 min |

So 7 of 9 alerts were isolated failures; both genuine outages were consecutive runs.

## Existing contracts

- `probe.py` runs all 12 targets once a minute and appends rows to `probe_results.jsonl`.
- `signal.py` turns rows into `Alert`s. `responder.py` renders them into one report and
  posts it to `#ops-alerts` when the report differs from the last one posted.
- `board.py` renders the on-call board from `state/responder_state.json`.

## Observation while tracing the 95-minute outage

After 30 minutes without a post the board showed "responder silent". The responder was
healthy: the outage report was unchanged, so `run_once` returned `UNCHANGED` before
writing state, and `board.py` treats `last_seen` older than 30 minutes as silence.

## Possible follow-up (not decided)

State may need versioning if more responder changes follow. The ticket allows responder
changes "where necessary"; whether this is one is open.
