**Plan for SYN-small**

## Recommendation

Extend `_delay` so a non-integer value is parsed as an HTTP date and converted to
seconds from now. Nothing else changes.

## Behaviour

- Integer value: unchanged.
- HTTP date in the future: seconds until then, rounded up, capped at `MAX_DELAY`.
- HTTP date in the past, or an unparseable value: `0` (retry immediately, as for
  `Retry-After: 0`) rather than raising. A malformed header from a server should not turn
  into a client crash.
- `_delay` gains an optional `now` argument defaulting to the current UTC time so the
  date case can be tested without sleeping.

## Verification

Table-driven test for `_delay` covering the five cases above plus the date exactly at the
cap. No change to the retry loop; the existing retry test still covers it.
